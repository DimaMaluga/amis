from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^$', views.main_list, name='main_list'),
    
    url(r'^details/(?P<pk>\d+)/$', views.details, name='details'),
    
    url(r'^order_details/(?P<pk>\d+)/$', views.order_details, name='order_details'),

    url(r'^profile/$', views.user_profile, name='profile'),
    url(r'^profile/(?P<pk>\d+)/$', views.user_profile, name='profile_pk'),

    url(r'^profile/delete_order/(?P<pk>\d+)/$', views.delete_order, name='delete_order'),

]

from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db import connection
from django.db import transaction
from django.contrib.auth.models import User

from .models import Clothes, Order, Basket

def main_list(request):
    template_name = 'main_list/home.html'

    clothes = Clothes.objects.all()

    return render(request, template_name, {'clothes': clothes})


def get_basket(pk):

    basket = Basket.objects.filter(user_id=pk)
    if not basket:
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('BASKET_PACKAGE.CREATE_BASKET', [pk])

    return Basket.objects.get(user_id=pk)


def details(request, pk):
    template_name = 'main_list/details.html'
    clothes_id = pk
    
    if request.method == "GET":
        clothes = Clothes.objects.get(pk=clothes_id)
        return render(request, template_name, {'clothes': clothes})

    elif request.method == "POST":
        clothes_number = int(request.POST.get('clothes_number'))
        new_id = ''
        clothes = Clothes.objects.get(pk=clothes_id)
        basket = get_basket(request.user.id)

        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            order_id = int(cursor.callproc('ORDER_PACKAGE.CREATE_ORDER', [
                request.user.id, clothes_id, clothes_number, new_id])[-1])

            cursor.callproc('BASKET_ORDER_PACKAGE.ADD_ORDER', [basket.id, order_id])

        # order = Order.objects.create(user=request.user, clothes_id=clothes_id, quantity=clothes_number)
        # basket.order.add(order)
        # basket.save()

        return redirect(reverse('main_list:order_details', args=(order_id,)))


def order_details(request, pk):
    if request.method == "GET":
        cursor = connection.cursor()
        cursor.execute('SELECT "USERNAME",\
                            "CLOTHES_NAME",\
                            "ORDER_QUANTITY",\
                            "CREATE_TIME" \
            FROM "ORDER_DETAILS_PAGE" \
            WHERE "ORDER_ID" = {id}'.format(id=pk))

        USERNAME, CLOTHES_NAME, ORDER_QUANTITY, CREATE_TIME = cursor.fetchone()
        
        context = {
            "USERNAME": USERNAME,
            "CLOTHES_NAME": CLOTHES_NAME,
            "ORDER_QUANTITY": ORDER_QUANTITY,
            "CREATE_TIME": CREATE_TIME,
        }
        
        # order = Order.objects.get(pk=pk)

        return render(request, 'order/order_details.html', context)

def get_bucket_price(basket):
    price = 0
    for order in basket.order.all():
        price += order.quantity*order.clothes.price

    return price

def user_profile(request, pk=None):
    can_order_basket = False
    if not pk:
        pk = request.user.id
        basket = get_basket(pk)
        if basket.order.exists():
            can_order_basket = True
    user = User.objects.get(pk=pk)

    if request.method == "GET":
        orders = Order.objects.filter(user_id=pk)

        bucket_price = get_bucket_price(basket)

        return render(request, 'profile/profile.html',
            {'basket': basket,
            'user': user,
            'can_order_basket': can_order_basket,
            'orders': orders,
            'bucket_price': bucket_price})

    if request.method == "POST":
        for order in basket.order.all():
            clothes = Clothes.objects.get(pk=order.clothes.id)

            if order.quantity <= clothes.quantity:
                
                with transaction.atomic():
                    cursor = connection.cursor()
                    cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                    cursor.callproc('BUY_BASKET_ORDER.BUY_ORDER', [
                        order.id, clothes.id, order.quantity])

                    # order.is_payed = True
                    # order.save()
                    # clothes.quantity -= order.quantity
                    # clothes.save()

                    cursor.callproc('BASKET_PACKAGE.DELETE_ORDER_FROM_BASKET', [
                            order.id])
                    # basket.order.remove(order)


        return redirect(reverse('main_list:profile'))


def delete_order(request, pk):
    if request.method == 'POST':

        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('ORDER_PACKAGE.DELETE_ORDER', [pk])
            # Order.objects.get(pk=pk).delete()

        return redirect(reverse('main_list:profile'))

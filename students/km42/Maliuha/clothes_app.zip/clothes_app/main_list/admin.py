from django.contrib import admin
from .models import Clothes, Order, Basket

admin.site.register(Clothes)
admin.site.register(Basket)
admin.site.register(Order)


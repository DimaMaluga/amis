from django.apps import AppConfig


class MainListConfig(AppConfig):
    name = 'main_list'

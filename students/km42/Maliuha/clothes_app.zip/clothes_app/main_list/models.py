from django.db import models

CLOTHES_CATEGORY = (
    ('Mans', 'Mans'),
    ('Womans', 'Womans'),
    ('Childs', 'Childs'),
    ('Adult', 'Adult'))


class Clothes(models.Model):
    name = models.CharField(max_length=45)
    description = models.CharField(max_length=200, blank=True, null=True)
    price = models.PositiveIntegerField(default=1)
    clothes_type = models.CharField(max_length=50, blank=True, null=True)
    category = models.CharField(
        max_length=7, choices=CLOTHES_CATEGORY, default='Mans',)
    quantity = models.PositiveIntegerField(default=1,)
    price = models.PositiveIntegerField(default=1,)

    class Meta:
        unique_together = (("name", "price"),)


class Order(models.Model):
    user = models.ForeignKey(
        'auth.User',
        verbose_name='User',
        on_delete=models.SET_NULL,
        null=True,
    )
    clothes = models.ForeignKey(
        'Clothes',
        verbose_name='Clothes',
        on_delete=models.SET_NULL,
        null=True,
    )
    quantity = models.PositiveIntegerField(
    	'quantity',
    	default=1,
    )
    create_time = models.DateTimeField(
        'Created',
        auto_now_add=True,
        null=True,
    )
    is_payed = models.NullBooleanField(default=False)

    def __str__(self):
        return '{username} order of {clothes} in {order_time}'.format(username=self.user.username,
            clothes=self.clothes.name, order_time=self.create_time)

    class Meta:
        verbose_name = "Order"
        verbose_name_plural = "Orders"


class Basket(models.Model):
    order = models.ManyToManyField(
        'Order',
        verbose_name='order',
    )
    user = models.OneToOneField(
        'auth.User',
        verbose_name='User',
        on_delete=models.SET_NULL,
        null=True,
    )


from django.conf.urls import url
from django.contrib.auth import views as auth

from . import views


urlpatterns = [

    url(r'^login/$', auth.login, name='login'),
    url(r'^signup/$', views.signup, name='signup'),

    url(r'^logout/$', auth.logout, {'next_page': '/'}, name='logout'),

]


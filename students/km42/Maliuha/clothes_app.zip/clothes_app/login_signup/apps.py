from django.apps import AppConfig


class LoginSignupConfig(AppConfig):
    name = 'login_signup'

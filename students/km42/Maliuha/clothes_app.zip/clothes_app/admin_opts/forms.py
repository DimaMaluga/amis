from django import forms
from django.forms.widgets import NumberInput, TextInput, DateTimeInput
import datetime
from main_list.models import Clothes, Order, Basket

CLOTHES_CATEGORY = (
    ('Mans', 'Mans'),
    ('Womans', 'Womans'),
    ('Childs', 'Childs'),
    ('Adult', 'Adult'))

class ClothesForm(forms.ModelForm):

    name = forms.CharField(max_length=35)
    description = forms.CharField(max_length=35, required=False)
    price = forms.IntegerField(required=True,
        widget=NumberInput(
            attrs={'class':'validate','min':"1",'max': "100"}))
    category = forms.ChoiceField(choices=CLOTHES_CATEGORY)
    clothes_type = forms.CharField(max_length=35, required=False)
    quantity = forms.IntegerField(required=True,
        widget=NumberInput(
            attrs={'class':'validate','min':"1",'max': "100"}))

    class Meta:
        model = Clothes
        fields = '__all__'


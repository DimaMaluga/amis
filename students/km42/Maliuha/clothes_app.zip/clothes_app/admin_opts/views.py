from django.shortcuts import render
from django.views import View
from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db import connection
from django.db import transaction
from django.contrib.auth.models import User

from main_list.models import Clothes, Order, Basket
from .forms import ClothesForm

def get_params(request):
    name = request.POST.get('name')
    description = request.POST.get('description') or ''
    price = int(request.POST.get('price'))
    category = request.POST.get('category')
    clothes_type = request.POST.get('clothes_type') or ''
    quantity = int(request.POST.get('quantity'))

    return name, description, price, category, clothes_type, quantity


class AdminOpts(View):
    def get(self, request):
        clothes = Clothes.objects.all()
        form = ClothesForm()
        return render(request, 'admin/admin.html', {'form': form, 'clothes': clothes})

    def post(self, request):
        clothes = Clothes.objects.all()
        form = ClothesForm(request.POST)
        if form.is_valid():

            name, description, price, category, clothes_type, quantity = get_params(request)

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('ADMIN_PACKAGE.CREATE_CLOTHES', [
                    name, description, price, category, clothes_type, quantity])

            # form.save()
            return redirect(reverse('admin_opts:admin_main'))

        return render(request, 'admin/admin.html', {'form': form, 'clothes': clothes})


class DeleteClothes(View):
    def post(self, request, pk):
        # clothes = Clothes.objects.get(pk=pk).delete()
        with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')
                cursor.callproc('ADMIN_PACKAGE.DELETE_CLOTHES', [pk])

        return redirect(reverse('admin_opts:admin_main'))


class EditClothes(View):

    def get(self, request, pk):
        clothes = Clothes.objects.get(pk=pk)
        form = ClothesForm(instance=clothes)
        return render(request, 'admin/admin_edit.html', {'form': form})

    def post(self, request, pk):
        clothes = Clothes.objects.get(pk=pk)
        form = ClothesForm(request.POST, instance=clothes)
        if form.is_valid():

            name, description, price, category, clothes_type, quantity = get_params(request)

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('ADMIN_PACKAGE.UPDATE_CLOTHES', [
                    pk, name, description, price, category, clothes_type, quantity])

            # form.save()
            return redirect(reverse('admin_opts:admin_main'))

        return render(request, 'admin/admin.html', {'form': form})

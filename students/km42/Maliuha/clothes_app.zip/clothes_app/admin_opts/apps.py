from django.apps import AppConfig


class AdminOptsConfig(AppConfig):
    name = 'admin_opts'

from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^$', views.AdminOpts.as_view(), name='admin_main'),

    url(r'^delete/(?P<pk>\d+)/$', views.DeleteClothes.as_view(), name='delete_clothes'),

    url(r'^edit/(?P<pk>\d+)/$', views.EditClothes.as_view(), name='edit_clothes'),

]

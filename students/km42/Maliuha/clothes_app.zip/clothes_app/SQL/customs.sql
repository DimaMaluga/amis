create or replace PACKAGE ADMIN_PACKAGE IS
    PROCEDURE CREATE_CLOTHES (
      clothes_name VARCHAR2, 
      clothes_description VARCHAR2, 
      clothes_price NUMBER, 
      clothes_category VARCHAR2, 
      clothes_clothes_type VARCHAR2, 
      clothes_quantity NUMBER);
    PROCEDURE UPDATE_CLOTHES (
      updating_clothes_id NUMBER,
      clothes_name VARCHAR2, 
      clothes_description VARCHAR2, 
      clothes_price NUMBER, 
      clothes_category VARCHAR2, 
      clothes_clothes_type VARCHAR2, 
      clothes_quantity NUMBER);
    PROCEDURE DELETE_CLOTHES (
      deleting_clothes_id NUMBER);
END ADMIN_PACKAGE;
/
COMMIT;

create or replace PACKAGE BODY ADMIN_PACKAGE IS 
    PROCEDURE CREATE_CLOTHES (
      clothes_name VARCHAR2, 
      clothes_description VARCHAR2, 
      clothes_price NUMBER, 
      clothes_category VARCHAR2, 
      clothes_clothes_type VARCHAR2, 
      clothes_quantity NUMBER) AS
        BEGIN
            INSERT INTO "MAIN_LIST_CLOTHES" (
              "NAME",
              "DESCRIPTION", 
              "PRICE", 
              "CATEGORY", 
              "CLOTHES_TYPE", 
              "QUANTITY")
            VALUES (
              clothes_name,
              clothes_description, 
              clothes_price, 
              clothes_category, 
              clothes_clothes_type, 
              clothes_quantity);
        END;

    PROCEDURE UPDATE_CLOTHES (
      updating_clothes_id NUMBER,
      clothes_name VARCHAR2, 
      clothes_description VARCHAR2, 
      clothes_price NUMBER, 
      clothes_category VARCHAR2, 
      clothes_clothes_type VARCHAR2, 
      clothes_quantity NUMBER) AS
        BEGIN
          UPDATE "MAIN_LIST_CLOTHES" SET
              "NAME" = clothes_name, 
              "DESCRIPTION" = clothes_description, 
              "PRICE" = clothes_price, 
              "CATEGORY" = clothes_category, 
              "CLOTHES_TYPE" = clothes_clothes_type,
              "QUANTITY" = clothes_quantity
            WHERE "ID" = updating_clothes_id;
        END;
     PROCEDURE DELETE_CLOTHES (
      deleting_clothes_id NUMBER) AS
        BEGIN
          DELETE "MAIN_LIST_CLOTHES" 
          WHERE "ID" = deleting_clothes_id;
        END;
END;
/
COMMIT;


CREATE OR REPLACE PACKAGE BASKET_PACKAGE IS
  PROCEDURE CREATE_BASKET (
    USER_ID NUMBER);
END BASKET_PACKAGE;
/
COMMIT;

create or replace PACKAGE BODY BASKET_PACKAGE IS 
  PROCEDURE CREATE_BASKET (
    USER_ID NUMBER) AS
    BEGIN
      INSERT INTO "MAIN_LIST_BASKET" (
        "USER_ID")
      VALUES (USER_ID);
    END;
END;
/
COMMIT;


CREATE OR REPLACE PACKAGE ORDER_PACKAGE IS
  PROCEDURE CREATE_ORDER (
    ORDER_USER_ID out NUMBER,
    ORDER_CLOTHES_ID NUMBER,
    ORDER_QUANTITY NUMBER);
END ORDER_PACKAGE;
/
COMMIT;

create or replace PACKAGE BODY ORDER_PACKAGE IS 
  PROCEDURE CREATE_ORDER (
    ORDER_USER_ID out NUMBER,
    ORDER_CLOTHES_ID NUMBER,
    ORDER_QUANTITY NUMBER) AS
    BEGIN
      INSERT INTO "MAIN_LIST_ORDER" ("USER_ID", "CLOTHES_ID", "QUANTITY")
      VALUES (ORDER_USER_ID, ORDER_CLOTHES_ID, ORDER_QUANTITY)
      RETURNING "ID" INTO ORDER_USER_ID;
    END;
END;
/
COMMIT;


CREATE OR REPLACE PACKAGE BASKET_PACKAGE IS
  PROCEDURE ADD_ORDER (
    ADD_BASKET_ID NUMBER,
    ADD_ORDER_ID NUMBER);
END BASKET_PACKAGE;
/
COMMIT;

create or replace PACKAGE BODY BASKET_PACKAGE IS 
  PROCEDURE ADD_ORDER (
    ADD_BASKET_ID NUMBER,
    ADD_ORDER_ID NUMBER) AS
    BEGIN
      INSERT INTO "MAIN_LIST_BASKET_ORDER" ("BASKET_ID", "ORDER_ID")
      VALUES (ADD_BASKET_ID, ADD_ORDER_ID);
    END;
END;
/
COMMIT;
